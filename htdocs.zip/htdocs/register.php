<!DOCTYPE html>
<html>
<head>

<title>Application Form</title>
        <link href='http://fonts.googleapis.com/css?family=Nunito:400,300' rel='stylesheet' type='text/css'>
<style>

          *, *:before, *:after {
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
}
/*Fixed Background Image*/
body {
    background-image: url('background.jpg');
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-position: center;
    font-family: 'Nunito', sans-serif;
    color: #384047;
}

form {
  max-width: 500px;
  margin: 10px auto;
  padding: 10px 20px;
  background: #f4f7f8;
  border-radius: 8px;
}

input[type="text"],
input[type="password"],
input[type="date"],
input[type="datetime"],
input[type="email"],
input[type="number"],
input[type="search"],
input[type="tel"],
input[type="time"],
input[type="url"],
textarea,
select {
  background: rgba(255,255,255,0.1);
  border: none;
  font-size: 16px;
  height: auto;
  margin: 0;
  outline: 0;
  padding: 15px;
  width: 100%;
  background-color: #e8eeef;
  color: #8a97a0;
  box-shadow: 0 1px 0 rgba(0,0,0,0.03) inset;
  margin-bottom: 30px;
}

input[type="radio"],
input[type="checkbox"] {
  margin: 0 4px 8px 0;
}

select {
  padding: 6px;
  height: 32px;
  border-radius: 2px;
}

button {
  padding: 19px 39px 18px 39px;
  color: #FFF;
  background-color: #4bc970;
  font-size: 18px;
  text-align: center;
  font-style: normal;
  border-radius: 5px;
  width: 100%;
  border: 1px solid #3ac162;
  border-width: 1px 1px 3px;
  box-shadow: 0 -1px 0 rgba(255,255,255,0.1) inset;
  margin-bottom: 10px;
}

fieldset {
  margin-bottom: 30px;
  border: none;
}

legend {
  font-size: 1.4em;
  margin-bottom: 10px;
}

label {
  display: block;
  margin-bottom: 8px;
}

label.light {
  font-weight: 300;
  display: inline;
}

.number {
  background-color: #5fcf80;
  color: #fff;
  height: 30px;
  width: 30px;
  display: inline-block;
  font-size: 0.8em;
  margin-right: 4px;
  line-height: 30px;
  text-align: center;
  text-shadow: 0 1px 0 rgba(255,255,255,0.2);
  border-radius: 100%;
}

div.transbox {

    background-color: #333;
    /*opacity: 0.6;

    filter: alpha(opacity=60); /* For IE8 and earlier */
}

div.transbox h1 {
    margin: 2%;
    text-align: center;
    font-size: 25px;
    color: white;
    font-family: Futura, "Trebuchet MS", Arial, sans-serif;
}


p{
  color: red;
  
}

</style>
<script>
function checkform ( form ) 
	{if(form.username.value=="")
	{
	alert("Please enter User Name");
	document.getElementById("uname").innerText = "Enter User Name";
	form.username.focus();
	return false;
	}
  if(form.password.value=="")
  {
  alert("Please enter a Password");
  document.getElementById("pass").innerText = "Enter Password";
  form.password.focus();
  return false;
  }
   if(form.password.value!=form.cpassword.value)
  {
  alert("Password Does Not Match");
  document.getElementById("cpass").innerText = "Password Does Not Match";
  form.cpassword.focus();
  return false;
  }
	
}
</script>

</head>
<body>

<p align="center">
<img src="logo1.png" align="center" alt="Logo Here" width="100%">
</p>

<div class="transbox">
	<h1>Register</h1>
</div>

<form action="register1.php" method="post" onsubmit="return checkform(this);">

<fieldset>
  <legend><span class="number">1</span>Enter Credentials</legend>
  User Name:<br>
  <input type="text" name="username" >
  <p id="uname"></p>
  <br>
  Password:<br>
  <input type="password" name="password" >
  <p id="pass"></p>
  <br>
  Confirm Password:<br>
  <input type="password" name="cpassword" >
  <p id="cpass"></p>
  <br>
</fieldset>

  <button type="submit" value="Submit">Register</button>
   
</form> 


</body>
</html>
