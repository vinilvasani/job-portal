<?php
//connecting to the database
define('DB_HOST', 'localhost');
define('DB_NAME', 'project1');
define('DB_USER','root');
define('DB_PASSWORD','');

$con=mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

$name = $_POST['companyname'];
$address = $_POST['companyaddress'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$type = $_POST['industry'];
$vacancy = $_POST['vacancies'];

$query = "INSERT INTO companyinfo(name,address,email,phone,type,vacancy)VALUES('$name','$address','$email','$phone','$type','$vacancy')";

$result = mysqli_query($con,$query);
if($result)
	{
	    echo "Successfully updated all database";
	}
	else
	{
	 die('Error: '.mysql_error($con));
	}
	mysqli_close($con);


?>