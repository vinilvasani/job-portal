<!DOCTYPE html>
<html>
<head>

<title>Application Form</title>
        <link href='http://fonts.googleapis.com/css?family=Nunito:400,300' rel='stylesheet' type='text/css'>
<style>

          *, *:before, *:after {
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
}
/*Fixed Background Image*/
body {
    background-image: url('background.jpg');
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-position: center;
    font-family: 'Nunito', sans-serif;
    color: #384047;
}

form {
  max-width: 500px;
  margin: 10px auto;
  padding: 10px 20px;
  background: #f4f7f8;
  border-radius: 8px;
}

input[type="text"],
input[type="password"],
input[type="date"],
input[type="datetime"],
input[type="email"],
input[type="number"],
input[type="search"],
input[type="tel"],
input[type="time"],
input[type="url"],
textarea,
select {
  background: rgba(255,255,255,0.1);
  border: none;
  font-size: 16px;
  height: auto;
  margin: 0;
  outline: 0;
  padding: 15px;
  width: 100%;
  background-color: #e8eeef;
  color: #8a97a0;
  box-shadow: 0 1px 0 rgba(0,0,0,0.03) inset;
  margin-bottom: 30px;
}

input[type="radio"],
input[type="checkbox"] {
  margin: 0 4px 8px 0;
}

select {
  padding: 6px;
  height: 32px;
  border-radius: 2px;
}

button {
  padding: 19px 39px 18px 39px;
  color: #FFF;
  background-color: #4bc970;
  font-size: 18px;
  text-align: center;
  font-style: normal;
  border-radius: 5px;
  width: 100%;
  border: 1px solid #3ac162;
  border-width: 1px 1px 3px;
  box-shadow: 0 -1px 0 rgba(255,255,255,0.1) inset;
  margin-bottom: 10px;
}

fieldset {
  margin-bottom: 30px;
  border: none;
}

legend {
  font-size: 1.4em;
  margin-bottom: 10px;
}

label {
  display: block;
  margin-bottom: 8px;
}

label.light {
  font-weight: 300;
  display: inline;
}

.number {
  background-color: #5fcf80;
  color: #fff;
  height: 30px;
  width: 30px;
  display: inline-block;
  font-size: 0.8em;
  margin-right: 4px;
  line-height: 30px;
  text-align: center;
  text-shadow: 0 1px 0 rgba(255,255,255,0.2);
  border-radius: 100%;
}

div.transbox {

    background-color: #333;
    /*opacity: 0.6;

    filter: alpha(opacity=60); /* For IE8 and earlier */
}

div.transbox h1 {
    margin: 2%;
    text-align: center;
    font-size: 25px;
    color: white;
    font-family: Futura, "Trebuchet MS", Arial, sans-serif;
}


p{
  color: red;
  
}

</style>
<script>
function checkform ( form ) 
	{if(form.firstname.value=="")
	{
	alert("Please enter First Name");
	document.getElementById("fname").innerText = "Enter First Name";
	form.firstname.focus();
	return false;
	}
	if(form.lastname.value=="")
	{
	alert("Please enter Last Name");
	document.getElementById("lname").innerText = "Enter Last Name";
	form.lastname.focus();
	return false;
	}
	var emailid=form.email.value; 
	var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/; 
	if(reg.test(emailid) == false) 
	{ 
	alert('Invalid Email Address.'); 
	form.email.focus();
	return false; 
	}
	
	var mobilenumber=form.phone.value;
	if(form.phone.value=="" || mobilenumber.length !=10)
	{
	alert("Please enter Valid 10 digit Mobile No");
	form.phone.focus();
	return false;
	}
	if(form.age.value<=18 || form.age.value=="")
	{
		alert("You are not eligible to apply for this job");
		form.age.focus();
		return false;
	}
}
</script>

</head>
<body>

<p align="center">
<img src="logo1.png" align="center" alt="Logo Here" width="100%">
</p>

<div class="transbox">
	<h1>Application Form</h1>
</div>

<form action="connection.php" method="post" onsubmit="return checkform(this);">

<fieldset>
  <legend><span class="number">1</span>Your basic info</legend>
  First name:<br>
  <input type="text" name="firstname" >
  <p id="fname"></p>
  <br>
  Last name:<br>
  <input type="text" name="lastname" >
  <p id="lname"></p>
  <br><br>
  Gender:<br>
  <input type="radio" name="gender" value="male" checked> Male<br>
  <input type="radio" name="gender" value="female"> Female<br><br>
  Email:<br>
<input type="text" name="email"><br>
Phone:<br>
<input type="text" name="phone"><br>
Age:<br>
<input type="number" name="age"><br>
Interests:<br>
<input type="checkbox" name="userinterest1" value="developments" checked>Developments<br>
   <input type="checkbox" name="userinterest2" value="design">Design<br>
   <input type="checkbox" name="userinterest3" value="business">Business<br><br>
</fieldset>

<fieldset>
<legend><span class="number">2</span>Resume Details</legend>
Biography:<br>
   <textarea name="user_bio"></textarea><br>
   Title:<br>
  <input type="text" name="title" >
  <br>
  Location:<br>
  <input type="text" name="loca" >
 	Skills:<br>
  <input type="text" name="skil" >
  <br>
   Job Category:<br><select name="user_job">
          <option value="internet_services">Internet Services</option>
            <option value="banking">Banking</option>
            <option value="financial">Financial</option>
            <option value="marketing">Marketing</option>
            <option value="web_designer">Web Designer</option>
            <option value="management">Management</option>
          </select><br><br>
  </fieldset>
  
  <fieldset>        
   <legend><span class="number">3</span>Experience</legend>
   Employer:<br>
  <input type="text" name="employer" >
  <br>
  Job Title:<br>
  <input type="text" name="jtitle" >
  <br>
Responsibilities:<br>
  <input type="text" name="respon" >
  <br>
Start Date:<br>
  <input type="date" id="startdate" name="exp_startdate"><br>
End Date:<br>
  <input type="date" id="enddate" name="exp_enddate">
  <br><br>
  </fieldset>

  <fieldset>
  <legend><span class="number">4</span>Education</legend>
   School Name:<br>
  <input type="text" name="sname" >
  <br>
   College Name:<br>
  <input type="text" name="coll" >
  <br>
 Qualification:<br>
  <input type="text" name="qualif" >
  <br>
 Notes:<br>
  <input type="text" name="notes" >
  </fieldset>
  <button type="submit" value="Submit">Submit Application</button>
   <button type="reset">Reset</button>
</form> 


</body>
</html>
