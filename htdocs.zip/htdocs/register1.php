<?php
//connecting to the database
define('DB_HOST', 'localhost');
define('DB_NAME', 'project1');
define('DB_USER','root');
define('DB_PASSWORD','');

$con=mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

$username = $_POST['username'];
$password = $_POST['cpassword'];



$query = "INSERT INTO register(username,password)VALUES('$username','$password')";

$result = mysqli_query($con,$query);
if($result)
	{
	    header("Location: login.php");
        exit();
	}
	else
	{
	 die('Error: '.mysql_error($con));
	}
	mysqli_close($con);


?>