<?php
//connecting to the database
define('DB_HOST', 'localhost');
define('DB_NAME', 'project1');
define('DB_USER','root');
define('DB_PASSWORD','');

$con=mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$gender = $_POST['gender'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$age = $_POST['age'];

$title = $_POST['title'];
$location = $_POST['loca'];
$skill = $_POST['skil'];
$job_category = $_POST['user_job'];

$employer = $_POST['employer'];
$job_title = $_POST['jtitle'];
$sdate = $_POST['exp_startdate'];
$edate = $_POST['exp_enddate'];

$sname = $_POST['sname'];
$cname = $_POST['coll'];


$query = "INSERT INTO basicinfo(fname,lname,gender,email,phone,age,title,location,skills,job_category,employer,job_title,startdate,enddate,school_name,college_name)VALUES('$firstname','$lastname','$gender','$email','$phone','$age','$title','$location','$skill','$job_category','$employer','$job_title','$sdate','$edate','$sname','$cname')";

$result = mysqli_query($con,$query);
if($result)
	{
	    echo "Successfully updated all database";
	}
	else
	{
	 die('Error: '.mysql_error($con));
	}
	mysqli_close($con);


?>