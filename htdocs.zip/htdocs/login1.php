<?php
//connecting to the database
define('DB_HOST', 'localhost');
define('DB_NAME', 'project1');
define('DB_USER','root');
define('DB_PASSWORD','');

$con=mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}


$username = $_POST['username'];
$password = $_POST['password'];

$query = "SELECT * FROM register WHERE username='$username' and password='$password'";
     
$result = mysqli_query($con, $query) or die(mysqli_error($con));
$count = mysqli_num_rows($result);


if ($count == 1){
$_SESSION['username'] = $username;
}else{
echo "User Name and Password Does Not Match";
}


if (isset($_SESSION['username'])){
$username = $_SESSION['username'];
header("Location: home.html");
exit();
 
}





$con->close();
?>
